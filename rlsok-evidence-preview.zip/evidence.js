window.RLSOK_EVIDENCE = {
  "circuit": {
    "tool": "NGSPICE / TRANSIENT ANALYSIS",
    "title": "An RC circuit that missed its target.",
    "description": "At 5 ms, the first design charged too slowly. The external AI read the failure, changed one component, and ran a new design version.",
    "beforeLabel": "INITIAL DESIGN · 10 kΩ",
    "beforeValue": "1.967 V",
    "beforeStatus": "FAIL · BELOW TARGET",
    "afterLabel": "REVISED DESIGN · 1 kΩ",
    "afterValue": "4.966 V",
    "afterStatus": "PASS · SAME TARGET",
    "change": "Changed: charging resistance 10 kΩ → 1 kΩ. Real ngspice rerun.",
    "target": "Output ≥ 4.9 V at 5 ms; current ≤ 6 mA.",
    "scope": "A real failure-to-revision loop for one ideal RC circuit. No physical board or manufacturing claim.",
    "widths": [
      39.34693162738896,
      99.32621196968178
    ]
  },
  "motor": {
    "tool": "NGSPICE + MUJOCO / COUPLED EXAMPLE",
    "title": "A motor-drive revision that moved the joint.",
    "description": "A sourced motor model exchanges current, torque, speed, and back EMF between two actual tools. The final design met the frozen angle and current targets.",
    "beforeLabel": "INITIAL EXCHANGE · 47 Ω",
    "beforeValue": "0.071 rad",
    "beforeStatus": "FAIL · INITIAL GUESS",
    "afterLabel": "REVISED + CHECKED · 4.7 Ω",
    "afterValue": "0.493 rad",
    "afterStatus": "PASS · COUPLED CHECKS",
    "change": "Changed: driver resistance 47 Ω → 4.7 Ω. Final current: 0.436 A.",
    "target": "Angle ≥ 0.25 rad at 0.1 s; |current| ≤ 0.5 A; frozen exchange residual limits.",
    "scope": "One ideal direct-drive motor and disk. Initial exchange was not converged. No complete robot or hardware qualification.",
    "widths": [
      14.153580871547597,
      98.54602689475168
    ]
  },
  "gpu": {
    "tool": "VORTEX-DERIVED GPU / FROZEN HOLDOUT",
    "title": "A GPU design change with measurable results.",
    "description": "The revised design passed the frozen development regression and a separate holdout. The score comes from RTL simulation cycles against the project baseline.",
    "beforeLabel": "FROZEN PROJECT BASELINE",
    "beforeValue": "1.000×",
    "beforeStatus": "REFERENCE",
    "afterLabel": "REVISED GPU DESIGN",
    "afterValue": "1.035×",
    "afterStatus": "HOLDOUT PASS · 184 CHECKS",
    "change": "Measured geometric cycle speedup: 3.48%. Some cases were slightly slower.",
    "target": "Frozen numerical correctness and per-case regression limits; independently checked.",
    "scope": "Simulation benchmark improvement. No NVIDIA-equivalent rating, full-chip PPA, or manufactured-GPU claim.",
    "widths": [
      96,
      100
    ]
  }
};
