'use strict';
(() => {
  const records = window.RLSOK_EVIDENCE;
  const tabs = [...document.querySelectorAll('[data-case]')];
  const set = (id, value) => { const e=document.getElementById(id); if(e) e.textContent=value; };
  function select(id) {
    const r=records[id]; if(!r) return;
    tabs.forEach(t=>{const active=t.dataset.case===id;t.setAttribute('aria-selected',String(active));t.tabIndex=active?0:-1;});
    document.getElementById('experiment').setAttribute('aria-labelledby','tab-'+id);
    set('experiment-tool',r.tool);set('experiment-title',r.title);set('experiment-description',r.description);
    set('before-label',r.beforeLabel);set('before-value',r.beforeValue);set('before-status',r.beforeStatus);
    set('after-label',r.afterLabel);set('after-value',r.afterValue);set('after-status',r.afterStatus);
    set('experiment-change',r.change);set('experiment-target',r.target);set('experiment-scope',r.scope);
    document.getElementById('before-bar').style.width=r.widths[0]+'%';document.getElementById('after-bar').style.width=r.widths[1]+'%';
    document.getElementById('evidence-link').href='evidence/'+id+'.json';
  }
  tabs.forEach((t,i)=>{
    t.addEventListener('click',()=>select(t.dataset.case));
    t.addEventListener('keydown',event=>{
      let next;if(event.key==='ArrowRight')next=(i+1)%tabs.length;if(event.key==='ArrowLeft')next=(i+tabs.length-1)%tabs.length;
      if(event.key==='Home')next=0;if(event.key==='End')next=tabs.length-1;
      if(next!==undefined){event.preventDefault();tabs[next].focus();select(tabs[next].dataset.case);}
    });
  });
  document.getElementById('copy-command')?.addEventListener('click',async()=>{
    try { await navigator.clipboard.writeText('.\\atoms.ps1 reality-engines');set('copy-feedback','Copied. Run inside an existing RLSOK workspace.'); }
    catch { set('copy-feedback','Select and copy: .\\atoms.ps1 reality-engines'); }
  });
  if(tabs.length)select('circuit');
})();
