'use strict';
(() => {
  const I = window.RLSOK_I18N;
  const $ = (s, el = document) => el.querySelector(s);
  let lang = 'en';
  try {
    const q = new URLSearchParams(location.search).get('lang');
    lang = q || localStorage.getItem('rlsok.lang') || ((navigator.language || '').toLowerCase().startsWith('zh') ? 'zh' : 'en');
  } catch (e) { /* storage blocked */ }
  if (!I[lang]) lang = 'en';
  const T = (k, vars) => {
    let s = (I[lang][k] ?? I.en[k] ?? k);
    if (vars) Object.entries(vars).forEach(([a, b]) => { s = s.replace(`{${a}}`, b); });
    return s;
  };
  let cases = null, stage = 'design', render = () => {};

  function apply() {
    document.documentElement.lang = lang === 'zh' ? 'zh-CN' : 'en';
    document.querySelectorAll('[data-t]').forEach((e) => { e.textContent = T(e.dataset.t); });
    document.querySelectorAll('[data-th]').forEach((e) => { e.innerHTML = T(e.dataset.th); }); // trusted dictionary only
    document.querySelectorAll('[data-lang]').forEach((b) => { b.textContent = T('lang'); b.setAttribute('aria-label', T('langLabel')); });
    setStage(stage, true);
    render();
  }
  document.querySelectorAll('[data-lang]').forEach((b) => b.addEventListener('click', () => {
    lang = lang === 'zh' ? 'en' : 'zh';
    try { localStorage.setItem('rlsok.lang', lang); } catch (e) { /* ignore */ }
    apply();
  }));

  // ------------------------------------------------------------------ hero loop
  const STEP = { design: 'design', simulate: 'simulate', fail: 'fail', revise: 'revise', simulate2: 'simulate', pass: 'pass' };
  function setStage(k, force) {
    if (k === stage && !force) return;
    stage = k;
    const el = $('#stage');
    if (el) { el.textContent = T('st_' + k); el.dataset.stage = k; }
    document.querySelectorAll('.steps li').forEach((li) => li.classList.toggle('on', li.dataset.s === STEP[k]));
  }
  async function hero() {
    const cv = $('#scope');
    if (!cv || !window.RLSOKScope) return;
    try {
      const data = await RLSOKScope.load('data/r7_wave.json');
      RLSOKScope.mount(cv, data, { get limit() { return T('limit'); } }, setStage);
    } catch (e) { $('#stage') && ($('#stage').textContent = 'data/r7_wave.json'); }
  }

  // ------------------------------------------------------------------ numbers from data
  async function loadCases() {
    try { cases = await (await fetch('data/cases.json')).json(); } catch (e) { cases = null; }
    if (!cases) return;
    const v7 = $('#v-r7'); if (v7) v7.textContent = cases.r7.final_tolerance;
    const vg = $('#v-g1'); if (vg) vg.textContent = cases.g1_level1.seeds;
    render();
  }

  // ------------------------------------------------------------------ case page
  const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  const kv = (pairs) => { const d = el('div', 'kv'); pairs.forEach(([k, v, ok]) => { const c = el('div', null, k); const b = el('b', ok ? 'ok' : null, v); c.appendChild(b); d.appendChild(c); }); return d; };
  const table = (head, rows) => {
    const w = el('div', 'tblwrap'), t = el('table', 'tbl'), tr = el('tr');
    head.forEach((h) => tr.appendChild(el('th', null, h))); const th = el('thead'); th.appendChild(tr); t.appendChild(th);
    const tb = el('tbody'); rows.forEach((r) => { const x = el('tr'); r.forEach((c) => { const td = el('td'); if (c instanceof Node) td.appendChild(c); else td.textContent = c; x.appendChild(td); }); tb.appendChild(x); });
    t.appendChild(tb); w.appendChild(t); return w;
  };
  const tag = (status, txt) => el('span', 'tag' + (status === 'ok' ? ' ok' : ''), txt);
  const srcLine = (c) => el('p', 'srcline', `${T('source')}: ${c.source} · ${T('sha')} ${c.sha256}`);

  function caseRoot() { return $('#case'); }
  render = function renderCase() {
    const root = caseRoot();
    if (!root || !cases) return;
    const id = new URLSearchParams(location.search).get('id') || 'r7';
    root.replaceChildren();
    const c = cases[id];
    if (!c) { root.appendChild(el('p', null, 'Unknown case')); return; }
    const h = el('h1');
    if (id === 'duck_level2') {
      h.textContent = T('cdk'); root.appendChild(h);
      root.appendChild(el('p', 'lead', T('duckNote')));
      root.appendChild(kv([[T('verdict'), T('FAILED')], [T('steps'), c.steps.toLocaleString()], [T('seeds'), c.seeds, true], [T('dr'), c.dr, true]]));
      root.appendChild(el('h2', null, T('segments')));
      root.appendChild(table(['', T('official'), T('trained'), T('lim'), T('verdict')],
        c.segments.map((s) => [`${s.segment} (${s.axis})`, s.official.toFixed(3), s.trained == null ? '—' : s.trained.toFixed(3), s.limit.toFixed(3),
          tag(s.pass ? 'ok' : '', s.pass ? T('PASS') : T('FAILED'))])));
    } else if (id === 'g1_level1') {
      h.textContent = T('g1k'); root.appendChild(h);
      root.appendChild(kv([[T('verdict'), T('VERIFIED'), true], [T('seeds'), c.seeds, true], ['max |Δobs|', c.max_obs_diff.toExponential(1)]]));
      root.appendChild(el('h2', null, T('g1track')));
      root.appendChild(table(['cmd', 'measured'], Object.entries(c.tracking).map(([k, v]) => [k, v.toFixed(3)])));
    } else {
      h.textContent = id === 'r4' ? T('c4k') : T('c7k'); root.appendChild(h);
      root.appendChild(el('p', 'lead', `${T('req')}: ${c.requirement}`));
      if (id === 'r4') {
        root.appendChild(kv([[T('verdict'), T('INFEASIBLE')], [T('measured'), `${c.round1.input_current_A.toFixed(2)} A > ${c.round1.limit_A} A`],
          [T('energy'), `${c.energy.p_in_max_W} W < ${c.energy.p_load_min_W} W`]]));
        [[1, c.round1.status, c.round1.reason, null], [2, c.round2.status, c.round2.reason, c.round2.diagnosis]].forEach(([n, st, reason, diag]) => {
          const r = el('div', 'round'), h3 = el('h3', null, T('round', { n })); h3.appendChild(tag('', st)); r.appendChild(h3);
          if (reason) { r.appendChild(el('p', 'lbl', T('reason'))); r.appendChild(el('p', 'quote', reason)); }
          if (diag) { r.appendChild(el('p', 'lbl', T('diagnosis'))); r.appendChild(el('p', 'quote', diag)); }
          root.appendChild(r);
        });
      } else {
        root.appendChild(kv([[T('verdict'), T('PASS'), true], ['tolerance', c.final_tolerance, true], ['fail case', `${c.fail_case.case}: ${c.fail_case.vout_min.toFixed(3)} V < ${c.fail_case.limit} V`]]));
        c.rounds.forEach((rd) => {
          const r = el('div', 'round'), h3 = el('h3', null, T('round', { n: rd.round })); h3.appendChild(tag(rd.status === 'PASS' ? 'ok' : '', rd.status)); r.appendChild(h3);
          if (rd.reason) { r.appendChild(el('p', 'lbl', T('reason'))); r.appendChild(el('p', 'quote', rd.reason)); }
          if (rd.diagnosis) { r.appendChild(el('p', 'lbl', T('diagnosis'))); r.appendChild(el('p', 'quote', rd.diagnosis)); }
          if (rd.changes) { r.appendChild(el('p', 'lbl', T('changes'))); r.appendChild(el('p', 'quote', rd.changes)); }
          root.appendChild(r);
        });
      }
      const a = el('a', 'btn', T('report')); a.href = c.report; root.appendChild(a);
    }
    root.appendChild(srcLine(c));
  };

  apply();
  hero();
  loadCases();
})();
